using TMPro;
using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class LobbyView : MonoBehaviour
{
    [Header("Room Creation")]
    public TMP_InputField createRoomNameInput;
    public Slider pointGoalSlider;
    public TMP_Text pointGoalValueText;
    public Button createRoomButton;

    [Header("Join Room")]
    public TMP_InputField joinRoomNameInput;
    public Button joinRoomButton;

    [Header("Room Actions")]
    public Button leaveRoomButton;
    public Button startGameButton;
    public TMP_Text roomInfoText;

    [Header("Player List")]
    public Transform playerListParent;
    public GameObject playerListItemPrefab;

    [Header("Waiting Popup")]
    public GameObject waitingPopup;
    public TMP_Text waitingText;
    public float blinkSpeed = 0.5f;

    private LobbyController controller;
    private Coroutine blinkCoroutine;

    void Start()
    {
        controller = FindObjectOfType<LobbyController>();
        if (controller == null) Debug.LogError("LobbyController missing");

        createRoomButton.onClick.AddListener(() =>
        {
            string roomName = createRoomNameInput.text.Trim();
            int pointGoal = (int)pointGoalSlider.value;
            if (!string.IsNullOrEmpty(roomName))
                controller.CreateRoom(roomName, pointGoal);
        });

        joinRoomButton.onClick.AddListener(() =>
        {
            string roomName = joinRoomNameInput.text.Trim();
            if (!string.IsNullOrEmpty(roomName))
                controller.JoinRoom(roomName);
        });

        leaveRoomButton.onClick.AddListener(() => controller.LeaveRoom());
        startGameButton.onClick.AddListener(() => controller.StartGame());

        pointGoalSlider.onValueChanged.AddListener(val =>
        {
            pointGoalValueText.text = ((int)val).ToString();
        });

        waitingPopup.SetActive(false);
    }

    public void UpdateRoomUI(string roomName, int playerCount, int maxPlayers, string hostName, bool isGameStarted)
    {
        roomInfoText.text = $"Room: {roomName}  ({playerCount}/{maxPlayers})  Host: {hostName}";
        startGameButton.gameObject.SetActive(controller.IsHost && !isGameStarted);
        leaveRoomButton.interactable = true;
        createRoomButton.interactable = false;
        joinRoomButton.interactable = false;
    }

    public void UpdatePlayerList(string[] playerNames)
    {
        // Clear existing
        foreach (Transform child in playerListParent)
            Destroy(child.gameObject);

        foreach (string name in playerNames)
        {
            var item = Instantiate(playerListItemPrefab, playerListParent);
            item.GetComponentInChildren<TMP_Text>().text = name;
        }
    }

    public void ShowWaitingForHost()
    {
        waitingPopup.SetActive(true);
        if (blinkCoroutine != null) StopCoroutine(blinkCoroutine);
        blinkCoroutine = StartCoroutine(BlinkText());
    }

    public void HideWaitingPopup()
    {
        waitingPopup.SetActive(false);
        if (blinkCoroutine != null) StopCoroutine(blinkCoroutine);
    }

    private IEnumerator BlinkText()
    {
        while (true)
        {
            waitingText.text = "Waiting for host to start game...";
            yield return new WaitForSeconds(blinkSpeed);
            waitingText.text = "Waiting for host to start game...  .";
            yield return new WaitForSeconds(blinkSpeed);
            waitingText.text = "Waiting for host to start game...  ..";
            yield return new WaitForSeconds(blinkSpeed);
            waitingText.text = "Waiting for host to start game...  ...";
            yield return new WaitForSeconds(blinkSpeed);
        }
    }

    private void OnDestroy()
    {
        createRoomButton.onClick.RemoveAllListeners();
        joinRoomButton.onClick.RemoveAllListeners();
        leaveRoomButton.onClick.RemoveAllListeners();
        startGameButton.onClick.RemoveAllListeners();
    }
}