using UnityEngine;
using UnityEngine.SceneManagement;

public class LobbyController : MonoBehaviour
{
    [SerializeField] private LobbyView view;
    private string currentRoomName;
    private bool isHost = false;

    public bool IsHost => isHost;

    private void Start()
    {
        // Safety check
        if (NetworkClientManager.Instance == null)
        {
            Debug.LogError("No persistent client manager!");
            return;
        }

        var tcp = NetworkClientManager.Instance.Tcp;
        tcp.OnMessageReceived += OnTcpMessage;
        tcp.OnDisconnected += OnDisconnected;

        // Request current room state? Or server will push.
    }

    private void OnTcpMessage(string message)
    {
        string[] parts = message.Split(' ');
        if (message.StartsWith("ROOM_UPDATE"))
        {
            // ROOM_UPDATE roomName playerCount maxPlayers hostName isGameStarted
            string roomName = parts[1];
            int playerCount = int.Parse(parts[2]);
            int maxPlayers = int.Parse(parts[3]);
            string hostName = parts[4];
            bool gameStarted = parts[5] == "1";
            view.UpdateRoomUI(roomName, playerCount, maxPlayers, hostName, gameStarted);
        }
        else if (message == "GAME_STARTED")
        {
            // Load game scene
            SceneManager.LoadScene("2_Sc_Game");
        }
        else if (message.StartsWith("ERROR"))
        {
           // view.ShowMessage("Error: " + message.Substring(6));
        }
    }

    private void OnDisconnected(string reason)
    {
        Debug.Log("Disconnected in lobby: " + reason);
        // Go back to main menu
        SceneManager.LoadScene("MainMenu");
    }

    // Public methods called by LobbyView buttons
    public void CreateRoom(string roomName, int pointGoal) =>
        NetworkClientManager.Instance.Tcp.SendMessage($"CREATE_ROOM {roomName} {pointGoal}");

    public void JoinRoom(string roomName) =>
        NetworkClientManager.Instance.Tcp.SendMessage($"JOIN_ROOM {roomName}");

    public void LeaveRoom() =>
        NetworkClientManager.Instance.Tcp.SendMessage("LEAVE_ROOM");

    public void StartGame() =>
        NetworkClientManager.Instance.Tcp.SendMessage("START_GAME");

    private void OnDestroy()
    {
        var tcp = NetworkClientManager.Instance?.Tcp;
        if (tcp != null)
        {
            tcp.OnMessageReceived -= OnTcpMessage;
            tcp.OnDisconnected -= OnDisconnected;
        }
    }
}